package com.zybooks.weighttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText username;
    private EditText password;
    private Button loginBTN;
    private TextView passwordMSG;

    private UserDB _db;
    private WeightDB _weights;
    private UserModel validUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = findViewById(R.id.textUsername);
        password = findViewById(R.id.textPassword);
        loginBTN = findViewById(R.id.buttonLogin);
        passwordMSG = findViewById(R.id.passwordMessage);

        // call the singleton
        _db = UserDB.getInstance(this);

        loginBTN.setOnClickListener(v -> handleLogin(v));

        // password validator
        password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!PasswordValidator.isValid(s.toString())) {
                    passwordMSG.setVisibility(View.VISIBLE);
                    loginBTN.setEnabled(false);
                } else {
                    passwordMSG.setVisibility(View.INVISIBLE);
                    loginBTN.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void handleLogin(View v) {
        String _username = username.getText().toString();
        String _password = password.getText().toString();

        LoginManager loginManager = new LoginManager(_db);

        if (!loginManager.isUserRegistered(_username)) {
            promptRegistration(_username, _password);
        } else if (loginManager.isValidUser(_username, _password)) {
            showToast("Login Success");
            loginSuccess(v, _username);
        } else {
            showIncorrectPassword();
        }
    }

    private void loginSuccess(View view, String _user) {
        _weights = WeightDB.getInstance(this);

        validUser = UserModel.getUserInstance();
        validUser.setUserName(_user);
        validUser.setGoal(_weights.getGoal(validUser));

        Intent intent = new Intent(this, main_screen.class);
        startActivity(intent);
    }

    private void promptRegistration(String username, String password) {
        new AlertDialog.Builder(this)
                .setTitle("Account Not Recognized")
                .setMessage("Would you like to register?")
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setPositiveButton("Yes", (dialog, which) -> registerUser(username, password))
                .setNegativeButton("No", null)
                .show();
    }

    private void registerUser(String username, String password) {
        boolean userAdded = _db.insertUser(username, password);
        if (userAdded) {
            showToast("Account added");
        } else {
            showToast("Account failed");
        }
    }

    private void showIncorrectPassword() {
        showToast("Incorrect Password!!!");
    }

    private void showToast(String message) {
        Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
    }
}
