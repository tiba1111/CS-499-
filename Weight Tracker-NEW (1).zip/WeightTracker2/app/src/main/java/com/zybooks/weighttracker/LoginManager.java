package com.zybooks.weighttracker;

public class LoginManager {

    private final UserDB db;

    public LoginManager(UserDB db) {
        this.db = db;
    }

    public boolean isUserRegistered(String username) {
        return db.checkUserName(username);
    }

    public boolean isValidUser(String username, String password) {
        return db.checkUserName(username) && db.checkUserPassword(username, password);
    }
}
