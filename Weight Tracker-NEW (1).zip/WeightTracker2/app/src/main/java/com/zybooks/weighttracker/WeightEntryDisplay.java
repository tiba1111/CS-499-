package com.zybooks.weighttracker;

public class WeightEntryDisplay {
    public final String date;
    public final float weight;
    public final float remaining;

    public WeightEntryDisplay(String date, float weight, float remaining){
        this.date = date;
        this.weight = weight;
        this.remaining = remaining;
    }
}
