package com.zybooks.weighttracker;

public class PasswordValidator {
    public static boolean isValid(String password) {
        return password != null && password.length() >= 5;
    }
}
