package com.zybooks.weighttracker;

public class GoalManager {

    private final WeightDB weightDB;
    private final UserModel user;

    public GoalManager(WeightDB weightDB, UserModel user){
        this.weightDB = weightDB;
        this.user = user;
    }

    public void updateGoal(float newGoal){
        user.setGoal(newGoal);
        weightDB.addGoal(user);
    }
}
