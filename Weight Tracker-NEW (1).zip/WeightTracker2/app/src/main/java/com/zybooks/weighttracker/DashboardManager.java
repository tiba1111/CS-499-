package com.zybooks.weighttracker;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

public class DashboardManager {

    private final WeightDB weightDB;
    private final UserModel user;

    public DashboardManager(WeightDB weightDB, UserModel user){
        this.weightDB = weightDB;
        this.user = user;
    }

    public List<WeightEntryDisplay> getDisplayData() throws ParseException {
        List<WeightsClass> allEntries = weightDB.getAllWeights(user);
        List<WeightEntryDisplay> displayList = new ArrayList<>();

        for(WeightsClass w : allEntries){
            float remaining = w.getWeight() - user.getGoal();
            displayList.add(new WeightEntryDisplay(w.getDate(), w.getWeight(), remaining));
        }
        return displayList;
    }
}
