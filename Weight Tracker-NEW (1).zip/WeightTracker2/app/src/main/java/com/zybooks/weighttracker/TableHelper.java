package com.zybooks.weighttracker;
import android.content.Context;
import android.view.Gravity;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import java.util.List;

public class TableHelper {

    public static void populateTable(Context ctx, TableLayout table, List<WeightEntryDisplay> data){
        // header row
        TableRow header = new TableRow(ctx);
        header.addView(createHeaderCell(ctx, "Date"));
        header.addView(createHeaderCell(ctx, "Weight"));
        header.addView(createHeaderCell(ctx, "Weight Remaining"));
        table.addView(header);

        // data rows
        for(WeightEntryDisplay entry : data){
            TableRow row = new TableRow(ctx);
            row.addView(createCell(ctx, entry.date));
            row.addView(createCell(ctx, String.valueOf(entry.weight)));
            row.addView(createCell(ctx, String.valueOf(entry.remaining)));
            table.addView(row);
        }
    }

    private static TextView createHeaderCell(Context ctx, String text){
        TextView tv = new TextView(ctx);
        tv.setText(text);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(10,10,10,10);
        return tv;
    }

    private static TextView createCell(Context ctx, String text){
        TextView tv = new TextView(ctx);
        tv.setText(text);
        tv.setGravity(Gravity.CENTER_HORIZONTAL);
        tv.setPadding(10,10,10,10);
        return tv;
    }
}
