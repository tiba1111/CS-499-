package com.zybooks.weighttracker;

import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.Toast;

import java.text.ParseException;

public class main_screen extends AppCompatActivity {

    private WeightDB weightDB;
    private UserModel user;
    private DashboardManager dashboardManager;
    private GoalManager goalManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen);

        // Initialize singletons
        weightDB = WeightDB.getInstance(this);
        user = UserModel.getUserInstance();

        dashboardManager = new DashboardManager(weightDB, user);
        goalManager = new GoalManager(weightDB, user);

        TableLayout table = findViewById(R.id.weight_table);
        try {
            TableHelper.populateTable(this, table, dashboardManager.getDisplayData());
        } catch (ParseException e) {
            e.printStackTrace();
        }

        Button editBtn = findViewById(R.id.buttonEditWeight);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.app_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        openSettings();
        return false;
    }

    public void openSettings() {
        Intent intent = new Intent(this, UserSettings.class);
        startActivity(intent);
    }

    public void openEdit(View view) {
        Intent intent = new Intent(this, edit_view.class);
        startActivity(intent);
    }

    public void openWeightForm(View view) {
        Intent intent = new Intent(this, weight_entry.class);
        startActivity(intent);
    }

    public void onNewGoal(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

        builder.setView(input)
                .setTitle("Enter New Goal Weight")
                .setMessage("Change your current goal of " + user.getGoal() + " lbs?")
                .setPositiveButton("Save", (dialog, which) -> {
                    try {
                        float newGoal = Float.parseFloat(input.getText().toString());
                        goalManager.updateGoal(newGoal);

                        // Refresh Activity to show updated table
                        finish();
                        overridePendingTransition(0, 0);
                        startActivity(getIntent());
                        overridePendingTransition(0, 0);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Invalid input!", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
